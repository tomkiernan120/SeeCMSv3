<?php
$see->html->js( '//maps.googleapis.com/maps/api/js?sensor=false', '', '' );
$see->html->js( 'SeeCMS%202015/map.js' );
?>
<div class="googlemap" id="map_canvas"></div>