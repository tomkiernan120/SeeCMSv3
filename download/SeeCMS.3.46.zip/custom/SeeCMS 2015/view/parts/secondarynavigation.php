<div class="snav">
<?php

echo $data;

?>
</div>