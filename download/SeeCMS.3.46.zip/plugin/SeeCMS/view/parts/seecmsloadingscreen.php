<div class="loadingoverlay"></div>
<div class="loading">
  <div class="loading-text"></div>
  <div class="wrapperloading">
    <div class="loadingwheel up"></div>
    <div class="loadingwheel down"></div>
  </div>
</div>