$(document).ready(function(){

  /*
	var mediaDropzone = new Dropzone("div#mediadropzone", {url: "../media/add"});
	var downloadsDropzone = new Dropzone("div#downloadsdropzone", {url: "../downloads/add"});

  mediaDropzone.on("sending", function(file, xhr, formData) {
    formData.append("parentid", mediafolder); // Will send the filesize along with the file as POST data.
  });
  
  mediaDropzone.on("queuecomplete", function(file) {
    loadMediaByFolder();
  });

  downloadsDropzone.on("sending", function(file, xhr, formData) {
    alert('uploading');
  });
  
  downloadsDropzone.on("queuecomplete", function(file) {
   alert('uploaded')
  });
  */
  
});