$(document).ready(function(){
	$('.stripey tr:nth-child(odd)').attr('class','odd');
	$('.stripey tr:nth-child(even)').attr('class','even');
})