<htmlheader>
<pageheader>
<banners>
<div class="container">
	<div class="col-lg-6 newsfeed">
		<newsfeed>
	</div>
	<div class="col-lg-6">
		<content1>
	</div>
	</div>
<pagefooter>