<div class="navbar navbar-default navbar-fixed-top">
	<div class="container">
		<div class="navbar-header">
      <a href="/" class="navbar-brand"><?php echo $see->siteTitle ?></a>
      <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <primarynavigation>
  </div>
</div>