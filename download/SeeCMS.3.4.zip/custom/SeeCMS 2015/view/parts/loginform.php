<div class="well bs-component">
	<div class="form-horizontal">
		<div class="login">
			<fieldset>
				<legend>Members login area</legend>
			
			<?php

			echo $data;
			?>

			</fieldset>
		</div>
	</div>
</div>

