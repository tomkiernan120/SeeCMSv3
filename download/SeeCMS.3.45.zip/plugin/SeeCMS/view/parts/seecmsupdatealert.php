<?php

if( is_object( $data ) ) {

  echo "<a href=\"/{$see->SeeCMS->cmsRoot}/admin/cmsupdate/\" class=\"updatebutton\">New update available</a>";

}
