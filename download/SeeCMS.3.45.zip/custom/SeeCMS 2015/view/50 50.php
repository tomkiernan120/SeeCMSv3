<htmlheader>
<pageheader>
<div class="wrap">
	<div class="container">
		<div class="jumbotron">
			<content4>
		</div>
	</div>
</div>
<div class="container half">
	<div class="col-lg-6">
		<content2>
	</div>
	<div class="col-lg-6">
		<content1>
	</div>
</div>
<pagefooter>