<div class="footer container">
	<p>&copy; Copyright SeeCMS <?php echo date('Y') ?></p>
</div>
<?php $see->html->end(); ?>