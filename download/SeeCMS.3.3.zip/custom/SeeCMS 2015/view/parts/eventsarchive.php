<div class="newsarchive">

<?php

echo $data;

?>

</div>
